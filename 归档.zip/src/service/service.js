
const service = {
  console: function (params) {
      console.log(JSON.parse(JSON.stringify(params)));
  }
}
export default service;

