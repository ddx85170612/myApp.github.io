let _url = '';

const API = {
    'createAccount': _url + 'api/login/createAccount',
    'getAccount': _url + 'api/login/getAccount',
    'obtainCat': 'api/viennaServer/itemCat/obtainCat', //首页商品分类查询 1
    'queryItemSpu': 'api/viennaServer/itemSpu/queryItemSpu', //首页商品分类查询 1
}

export default API
