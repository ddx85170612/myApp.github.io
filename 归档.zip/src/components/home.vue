<template>
  <div>
  </div>
</template>
<script>
import URL from '../config/URL.js';
import axios from 'axios';

export default {
  data() {
    return {
      items: []
    }
  },
  
}
</script>

<style lang="less">

</style>
